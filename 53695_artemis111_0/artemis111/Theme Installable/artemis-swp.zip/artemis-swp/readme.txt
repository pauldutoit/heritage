Lucille
	by SmartWpress

ABOUT LUCILLE

Lucille is a highly customizable responsive WordPress theme designed for musicians and music bands. Lucille allows you to use predefined header layouts, offer customization for menu colour, menu transparency, unlimited logo colour options and different logo layouts. It is designed to fit your needs, for every music style. 
Lucille theme allows you to build your website by offering custom post types for events, albums, photos and videos and slides for full screen slider. It also offers support for youtube and vimeo videos.
